function phi = getfeatures(state)
% GETFEATURES, usage phi = getfeatures(state)

phi = state(:);